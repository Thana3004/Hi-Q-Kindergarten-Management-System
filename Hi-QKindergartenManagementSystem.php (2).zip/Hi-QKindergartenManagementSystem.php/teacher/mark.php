<?php 
include ('db.php');
session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
 
        if (isset($_GET["rno"]))
        {
            $sql="select * from students where student_id='{$_GET["rno"]}'";
            $res=$con->query($sql);
            if ($res->num_rows<=0)
            {
                header("location: add_mark.php?err=Invalid Student Id");
            }
            else{
                $rows=$res->fetch_assoc();
                $class=$rows["student_grade_id"];
                $regno=$_GET["rno"];
                $name=$rows["fname"];
            }
        }
 
?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Teacher- Exam Mark</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>
<style>
.body {
  font-family:cambria;
  font-size: 20px;
}
</style>
<body>
    
    <?php
    include ('db.php');
    
    ?>
    
    <?php 
    
        include ('navbar.php');
     ?>
    <br>





<?php
if (isset($_POST["submit"])){
    $sq="insert into mark (student_id,name,subject,mark,term,class,grade) Values ('{$_POST["regno"]}','{$_POST["name"]}','{$_POST["sub"]}','{$_POST["mark"]}','{$_POST["etype"]}','{$_POST["class"]}','{$_POST["grade"]}')";
    if ($con->query($sq))
    {
        $_SESSION['success']="Successfully Added";
            header("Location: add_mark.php");
    } else {
        $_SESSION['success']="Not Successfull! Pls try again";
          header("Location: add_mark.php");
    }
}

?>
<form method="post" align="center" action="<?php echo $_SERVER["REQUEST_URI"];?>">
    
    <div class="body">
        <h3 align="center"> Add marks </h3><br>
    <div class="1box">
        <label>Student id </Label>
        <input type="text" style="background: #b1b1b1;" class="input3" name="regno" readonly=""  value="<?Php echo $regno;?>">
        <br>
        <br>
        <label>Student Name </Label>
        <input type="text" style="background: #b1b1b1;" class="input3" name="name" readonly=""  value="<?Php echo $name;?>">
        <br>
        <br>
        <label>Class </Label>
        <input type="text" style="background: #b1b1b1;" class="input3" name="class" readonly="" value="<?Php echo $class;?>">
        <br>
         <br>
        <label> Exam Term </label>
        <select name="etype" required class="input3">
            <option value="">Select</option>
            <option value="Mid-Year Examination">Mid-Year Examination</option>
      
            <option value="Final Exam">Final Exam</option>
        </select>
               </div>
         <br>
    <div class="rbox">
        <label> Subject </label>
        <select name="sub" required class="input3">
            <?php 
            $s="select * from tbl_subject";
            $re=$con->query($s);
            if ($re->num_rows>0)
            {
                echo"<option value=''>Select</option>";
                while ($r=$re->fetch_assoc())
                {
                    echo"<option value='{$r["subject_name"]}'>{$r["subject_name"]}</option>";
                }
            }
            
            ?>
        </select>
    </div>
    
     <br>
    
    
    
     <div class="1box">
         <?php
         include ('../function.php');
         ?>
        <label> Mark</Label>
        <input type="text" autocomplete="off" maxlength="3" onkeypress="isInputNumber(event)" class="input3" name="mark" required="" >
        <br>
        <br>
        <label> Grade </label>
        <select name="grade" required class="input3">
            <option value="">Select</option>
            <option value="Pass">Pass</option>
      
            <option value="Failed">Failed</option>
        </select>
     </div>
     <br>
     <button type="submit" class="btn-primary" name="submit">Add Mark</button>    <a href="add_mark.php" class="btn-primary">Go Back</a>
        
        
     </div>
</div>
</html>
<?php 

  }else {
    header("Location: ../login2.php");
    exit;
  } 
}else {
	header("Location: ../login2.php");
	exit;
} 

?> 