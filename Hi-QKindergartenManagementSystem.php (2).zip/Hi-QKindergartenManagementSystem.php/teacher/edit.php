<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin- Edit Student data</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       
	<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
    session_start();
    include ('../db.php/db.php');
    
    ?>
    
    <?php 
        include "inc/navbar.php";
     ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> Edit Data</h6>
        </div>
            <div class="card-body">
                <?php 
                 $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
                if (isset($_POST['data_edit'])){
                    $id=$_POST['edit_id'];
                    $query= "select * from students where student_id='$id'";
                    $query_run= mysqli_query($conn, $query);
                    foreach ($query_run as $row){
                        ?>
                <form action="code.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="edited_id" value="<?php echo $row['student_id']?>">
                    <div class="form-group">
                      <fieldset class="border p-3">
          <legend  class="w-auto">Has student ever attend kindergarten?</legend> 
          <label> Year</label>
          <input type="text" name="year" class="form-control" placeholder=" 2020" value="<?php echo $row['year_of_previouse_kindergarten']?>" >
              <br>
             <label> Yes OR No</label>
             <input type="text" name="yesno" class="form-control" placeholder="Yes Or NO" value="<?php echo $row['previouse_kindergaten']?>"> 
         </fieldset>
              </div>
         
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Child Particular</legend> 
          <label> Name</label>
              <input type="text" name="name" class="form-control" placeholder=" Student name" value="<?php echo $row['fname']?>"  >
              <br>
             <label> Gender</label>
             <input type="text" name="gender" class="form-control" placeholder="Female or Male" value="<?php echo $row['gender']?>" > 
               <br>
             <label> Date of birth </label>
             <input type="date" name="dob" class="form-control"  value="<?php echo $row['dob']?>" > 
              <br>
             <label> Age </label>
             <input type="text" name="age" class="form-control"  placeholder=" example 6 years old" value="<?php echo $row['age']?>" > 
             <br>
             <label> Tel </label>
             <input type="text" name="tel" class="form-control"  placeholder=" 011-xxxxxxxx" value="<?php echo $row['mobile']?>" > 
             <br>
             <label> Home Address  </label>
             <input type="text" name="home" class="form-control"  placeholder=" No, 5 Jalan....." value="<?php echo $row['current_address']?>" > 
             <br>
             <label> Home Language  </label>
             <input type="text" name="homelang" class="form-control"  placeholder=" english, malay, mandrin..." value="<?php echo $row['Home_language']?>"> 
              <br>
             <label> Student Language  </label>
             <input type="text" name="stdlang" class="form-control"  placeholder=" english, malay, mandrin..." value="<?php echo $row['student_language']?>">
              <br>
             <label> Allergies  </label>
             <input type="text" name="all" class="form-control"  placeholder=" Example: seafood, dust...." value="<?php echo $row['allergies']?>">
             <br>
             <label> Photo  </label>
             <input type="file" name="photo"   id="photo">
              <div class="form_control">
		   <img src="../admin/upload/<?php echo $row['photo']; ?>" width="100" height="70" />
		  </div>
             <br>
             <label> Class  </label>
             <input type="text" name="class" class="form-control"  placeholder="Nemo" value="<?php echo $row['class']?>">
         </fieldset>
              </div>
          
         <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Parents Details</legend> 
          <label> Father Name</label>
              <input type="text" name="fname" class="form-control" placeholder=" father name " value="<?php echo $row['father_name']?>">
              <br>
             <label> Father IC Number</label>
             <input type="text" name="fic" class="form-control" placeholder="90xxxx-xx-xxxx" value="<?php echo $row['father_ic']?>"> 
               <br>
             <label> Father Occupation </label>
             <input type="text" name="focc" class="form-control" placeholder="Example: Business man, Teacher...." value="<?php echo $row['father_occupation']?>"> 
              <br>
             <label> Father Contact Number </label>
             <input type="text" name="fcontact" class="form-control"  placeholder="011-xxxxxxxx" value="<?php echo $row['father_mobile']?>" > 
             <br>
              <label> Mother Name</label>
              <input type="text" name="mname" class="form-control" placeholder=" mother name " value="<?php echo $row['mother_name']?>">
              <br>
             <label> Mother IC Number</label>
             <input type="text" name="mic" class="form-control" placeholder="90xxxx-xx-xxxx" value="<?php echo $row['mother_ic']?>"> 
               <br>
             <label> Mother Occupation </label>
             <input type="text" name="mocc" class="form-control" placeholder="Example: Business man, Teacher...." value="<?php echo $row['mother_occupation']?>"> 
              <br>
             <label> Mother Contact Number </label>
             <input type="text" name="mcontact" class="form-control"  placeholder="011-xxxxxxxx" value="<?php echo $row['mother_mobile']?>"> 
             <br>
         </fieldset>
              </div>
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Guardian Details</legend> 
           <label> Guardian Name</label>
              <input type="text" name="gname" class="form-control" placeholder="  name " value="<?php echo $row['Guardian_name']?>">
              <br>
             <label> Guardian IC Number</label>
             <input type="text" name="gic" class="form-control" placeholder="90xxxx-xx-xxxx" value="<?php echo $row['Guardian_ic']?>"> 
               <br>
             <label> Relationship to this student </label>
             <input type="text" name="grelation" class="form-control" placeholder="Example: grandfather, aunty" value="<?php echo $row['Guardian_Relationship']?>" > 
              <br>
             <label> Guardian Contact Number </label>
             <input type="text" name="gcontact" class="form-control"  placeholder="011-xxxxxxxx" value="<?php echo $row['guardian_contactnum']?>"> 
            </fieldset>
             </div>
          
          
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Emergency Details</legend> 
            <label> Contact Number </label>
             <input type="text" name="contactnum" class="form-control"  placeholder=" 011-xxxxxxxx" value="<?php echo $row['Emergency_Contactnum']?>"> 
             </fieldset>
             </div>

           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Registration Details</legend> 
            <label> Academic of Year </label>
             <input type="text" name="academicyear" class="form-control"  placeholder=" 2023" value="<?php echo $row['academic_year']?>"> 
             <br>
              <label> Admission Date </label>
             <input type="date" name="admissiondate" class="form-control"  value="<?php echo $row['admission_date']?>"> 
             </fieldset>
             </div>
                    <div class="modal-footer">
                        <a href ="students.php"><button type="button" class="btn btn-secondary">CLOSE</button></a>
                        <button type="submit" name="update" class="btn btn-primary">UPDATE</button>
                    </div>
                    
          
                   
                </form>
                 <?php
                    }
                }
                ?>
                </div>
    </div>
    
</body>
</html>
