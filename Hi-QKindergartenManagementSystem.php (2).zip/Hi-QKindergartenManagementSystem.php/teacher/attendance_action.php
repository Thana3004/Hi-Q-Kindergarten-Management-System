<?php
	if(isset($_POST["btnsubmit"]))
	{
		 include ('db.php');
		
		$date = $_POST["cyear"]."-".$_POST["cmonth"]."-".$_POST["cdate"];
               		
		$query = "select *from `students` ";
		$result = mysqli_query($con,$query)or die("select error");
		while($rec = mysqli_fetch_array($result))
		{
			$mno = $rec["student_id"];
                        $mmno = $rec["fname"];
                         $class = $rec["student_grade_id"];
			if(isset($_POST[$mno]))

			{
				$query1 = "INSERT INTO  `tbl_attendance`(`student_id` , `name` , `class`, `attendance_date` ,  `attendance_status`) VALUES('$mno','$mmno','$class','$date','1')";
			}
			else
			{
				$query1 = "INSERT INTO  `tbl_attendance`(`student_id` , `name` , `class`, `attendance_date` ,  `attendance_status`) VALUES('$mno','$mmno','$class','$date','0')";
			}
			mysqli_query($con,$query1)or die("insert error".$mno);
			print "<script>";
			print "alert('Attendance get successfully....');";
			print "self.location='attendance.php';";
			print "</script>";
		}
		
		
			
		
	}
	else
	{
		header("Location:attendance.php");
	}
?>