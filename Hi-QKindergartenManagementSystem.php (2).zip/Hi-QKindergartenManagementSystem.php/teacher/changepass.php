<?php 

session_start();

if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
 ?>



<html>
    
    <body>
 <?php
include("../db.php/dbb.php");

$password=$_POST['password'];
$password2=$_POST['password2'];

$status = "OK";
$msg="";

$count=$conn->prepare("select password from teachers where teacher_id=:teacher_id");
$count->bindParam(":teacher_id",$_SESSION['teacher_id'],PDO::PARAM_STR, 15);
$count->execute();
$row = $count->fetch(PDO::FETCH_OBJ);



if ( strlen($password) < 3 or strlen($password) > 8 ){
$msg.="Password must be more than 3 char legth and maximum 8 char lenght<BR>";
$status= "NOTOK";}

if ( $password <> $password2 ){
      $_SESSION['success'] = " Password not match pls try again";
        header('Location: setting.php');
    $status= "NOTOK";
        
}
    else
    {
        $_SESSION['success'] = " Password match";
        header('Location: setting.php');
       $status = "OK";
    
}

if($status<>"OK"){ 
echo "<font face='Verdana' size='2' color=red>$msg</font><br><center><input type='button' value='Retry' onClick='history.go(-1)'></center>";
}else{ 
    
         $password=$_POST['password'];

        $hash = password_hash($password, PASSWORD_DEFAULT); 


$sql=$conn->prepare("update teachers set password=:password where teacher_id='$_SESSION[teacher_id]'");
$sql->bindParam(':password',$hash,PDO::PARAM_STR, 32);
if($sql->execute()){

    $_SESSION['success'] = " Successfully Changed Password";
        header('Location: setting.php');
    }
    else
    {
        $_SESSION['success'] = " Password Not Change! Pls try again";
        header('Location: setting.php');
       
    }
   
}



?>


    </body><!-- comment -->
</html><!-- comment -->

<?php 

  }else {
    header("Location: ../login2.php");
    exit;
  } 
}else {
	header("Location: ../login2.php");
	exit;
} 

?>












