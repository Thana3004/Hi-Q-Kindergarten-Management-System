<?php 

session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
 
        
        
 
?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Teacher - Attendance</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       
<script type="text/javascript">
	function getatt(value)
	{
		if(value == true)
		{
			document.getElementById("txtAbsent").value = parseInt(document.getElementById("txtAbsent").value) - 1;
			document.getElementById("txtPresent").value = parseInt(document.getElementById("txtPresent").value) + 1;
		}
		else
		{
			document.getElementById("txtAbsent").value = parseInt(document.getElementById("txtAbsent").value) + 1;
			document.getElementById("txtPresent").value = parseInt(document.getElementById("txtPresent").value) - 1;
		}
	}
</script>



<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
    
    include ('db.php');
    
    ?>
    
    <?php 
        include "navbar.php";
     ?>

     <div class="container-fluid">
       <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>        
        <br>
        
    </div>
 
    
    
    
    

    <br><!-- comment -->
    <br>



    <form action="attendance_action.php" method="post">
        <table width="180px" align="left" style="">
            	<tr>
                	<td> Select date : <br />
                   <?php 
				 		    $dt = getdate();
							$day = $dt["mday"];
							$month = date("m");
							$year = $dt["year"];
							
							echo "<select name='cdate'>";
							for($a=1;$a<=31;$a++)
							{
								if($day == $a)
									echo "<option value='$a' selected='selected'>$a</option>";
								else
									echo "<option value='$a' >$a</option>";
							}
							echo "</select><select name='cmonth'>";
							for($a=1;$a<=12;$a++)
							{
								if($month == $a)
									echo "<option value='$a' selected='selected'>$a</option>";
								else
									echo "<option value='$a' >$a</option>";
							}
							echo "</select><select name='cyear'>";
							for($a=2010;$a<=$year;$a++)
							{
								if($year == $a)
									echo "<option value='$a' selected='selected'>$a</option>";
								else
									echo "<option value='$a' >$a</option>";
							}
							echo "</select>";
						?>                    
                    </td>
                </tr>
             </table>	
        
          <table width="1000" height="100" border="2" align="left" bordercolor="#9966FF" bgcolor="palegreen" style="margin-left:20px;">
            <tr>
              <td colspan="4" bgcolor="limegreen"><div align="center"><strong><span class="style2">Get Attendance</span></strong></div></td>
            </tr>
            <tr bgcolor="mediumseagreen">
              <td width="100px"><span class="style7">Student ID</span></td>
              <td width="152"><span class="style7">Name</span></td>
               <td width="152"><span class="style7">Class</span></td>
              <td width="110"><span class="style7">Attend</span></td>
            </tr>
            <?php
				 include ('db.php');
				extract($_POST);
				$query = "select *from `students` order by `student_id`";
				$s = 0;
				$result = mysqli_query($con,$query)or die("select error");
				while($rec = mysqli_fetch_array($result))
				{
					$s = $s + 1;
					echo ' <tr>
							  <td width="114">'.$rec["student_id"].'</td>
							  <td width="152">'.$rec["fname"].'</td>
                                                           <td width="152">'.$rec["student_grade_id"].'</td>   
							  <td width="110"><input type=checkbox name='.$rec["student_id"].' onclick="getatt(this.checked);"/></td>
							</tr>';
				}
			?>			
            <tr>
              <td colspan="3"><div align="center">
                <input type="submit" value="Get Attendance" name="btnsubmit"/>
                &nbsp;&nbsp;</div></td>
            </tr>
          </table>
    </form>
         
         	<table width="100px" align="right" style="margin-left:35px">
            	<tr>
                    <td> Total Absent : <input type="text" id="txtAbsent" value="<?php print$s;?>" size="10" disabled="disabled"/></td>
                </tr>
                <tr>
                	<td> Total Present : <input type="text" id="txtPresent" value="0" size="10"  disabled="disabled"/></td>
                </tr>
                <tr>
                	<td> Total Student : <input type="text" id="txtStrength" value="<?php print$s;?>" size="10" disabled="disabled"/></td>
                </tr>
             </table>
</td><!-- comment -->
</tr><!-- comment -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>
    </form>
<?php 

  }else {
    header("Location: ../login2.php");
    exit;
  } 
}else {
	header("Location: ../login2.php");
	exit;
} 

?>

