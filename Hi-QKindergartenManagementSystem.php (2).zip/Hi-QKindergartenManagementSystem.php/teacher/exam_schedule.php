<?php 

session_start();
if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
 
        
        
 
?>
 <head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Teacher- Exam Schedule</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
  
    include ('../db.php/db.php');
    
    ?>
    
    <?php 
        include "navbar.php";
     ?>

    
    
    
     







<div class="card-body" >
        <div class="col-md-7">
            <form action="" method="GET">
        <div class="input-group mb-3">
            <input type="text" autocomplete="off" name="search" value="<?php if(isset($_GET['search'])){echo $_GET['search'];} ?>" class="form-control" placeholder="search data" >
            <button type="submit" class="btn btn-primary">Search</button>
</div>
            </form>  
        </div>
        
    </div>
    
    
    
    
    
    
    
    <div class="table-responsive">
        <?php
       $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
        $query ="select * from tbl_exam";
        $query_run= mysqli_query($conn, $query);
       
        ?>
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0%" >
            <thead>
             <tr class="bg-dark text-light">
                
                <th>Exam ID</th>
                <th> Exam Type</th>
                <th> Exam Time</th>
                <th> Class</th>
                <th>subject</th>
               <th>Exam Date</th>     
               
              
            </tr>
            </thead>
            <tbody>
               
                <?php
                if (isset($_GET['search'])){
                    $filtervalues=$_GET['search'];
                    $query="select * from tbl_exam where CONCAT(exam_type)LIKE '%$filtervalues%' ";
                    $query_run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                    if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['exam_id']; ?></td>
                                              
                                                    <td><?= $items['exam_type']; ?></td>                         
                                                    <td><?= $items['duration']; ?></td>        
                                                    <td><?= $items['class']; ?></td>
                                                
                                                   
                                                    <td><?= $items['subject']; ?></td>
                                                    <td><?= $items['exam_date']; ?></td>
                                     
                                                  
                                         
                                                    
                                                 
                  
                        
                        
                                    
                                                       
                                                       
                                                       
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                    
                    }
                }
                
                ?>




                <?php
                if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                ?>
                
                <tr>
                    <td><?php echo $row['exam_id']?></td>
                       <td><?php echo $row['exam_type']?></td>
                    <td><?php echo $row['duration']?></td>
                       <td><?php echo $row['class']?></td>
           
                   <td><?php echo $row['subject']?></td>
                   <td><?php echo $row['exam_date']?></td>
                   
                    
                   
                   
                  
                        
                  
                
                </tr>
                <?php
                }
                }else{
                    echo "No record Found";
                }
                    
                ?>
            </tbody>
        </table>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(7) a").addClass('active');
        });
    </script>
    <br>
        <div class="text-center" >
            <button onclick=" window.print()" class=" btn btn-primary">Print</button>
            
        </div>
</body>

</html>
<?php 

  }else {
    header("Location: ../login2.php");
    exit;
  } 
}else {
	header("Location: ../login2.php");
	exit;
} 

?>
