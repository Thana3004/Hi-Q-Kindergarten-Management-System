<?php 

session_start();

if (isset($_SESSION['teacher_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Teacher') {
 ?>




<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Teacher- Setting</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
   
   include("../db.php/dbb.php");
    ?>
    
    <?php 
        include "navbar.php";
     ?>

    
    
    




<br>
<br>
 <div class="container-fluid">
        <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>
        
        <br>
        <br>
    </div>


<h2 style="text-align:center;">Change Your Password</h2>

<form action="changepass.php" method="post">
    <table align="center">
        
   
    <tr>
            <td><b>Enter New Password:</b></td>
            <td><input type="password" name="password" required=""></td>
       </tr>
 
         <tr>
         <td><b> Enter New Password Again:</b></td>
         <td><input type="password" name="password2" required=""></td>
        </tr>
        <br>
            <tr align="right">
                <td colspan="2"><br><input type="submit" name="change_pass" value="Change Password"/> <input type=reset value=Reset></br></td>
            </tr>
</table>
</form>
<?php

include("../db.php/dbb.php");

?>








    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(8) a").addClass('active');
        });
    </script>


</body>

</html>
<?php 

  }else {
    header("Location: ../login2.php");
    exit;
  } 
}else {
	header("Location: ../login2.php");
	exit;
} 

?>