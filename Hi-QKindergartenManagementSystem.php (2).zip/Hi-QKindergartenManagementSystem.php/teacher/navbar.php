<nav class="navbar navbar-expand-lg navbar-dark bg-success">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php">
      <img src="../logo.php/logo.jpeg" width="40">
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"
          id="navLinks">
        <li class="nav-item">
          <a class="nav-link" 
             aria-current="page" 
             href="index.php">Dashboard</a>
        </li>
       
        <li class="nav-item">
          <a class="nav-link" href="students.php">Students Details</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="attendance.php"> Attendance</a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="deleletattendance.php"> Modify Attendance</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add_mark.php"> Exam Mark</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="viewmark.php"> Modify Exam Mark</a>
        </li>
        
        <li class="nav-item">
          <a class="nav-link" href="exam_schedule.php">  Exam Schedule</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="setting.php">Setting</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact"></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#contact"></a>
        </li>
      </ul>
      <ul class="navbar-nav me-right mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="../logout.php">Logout</a>
        </li>
      </ul>
  </div>
    </div>
</nav>