<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin-Students</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       



<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
    session_start();
    include ('db.php');
    
    ?>
    
    <?php 
        include "navbar.php";
     ?>

    
    
    
    

    <br><!-- comment -->
    <br>

   <tr>
        <td><div align="center">
        <form action="" method="post">
          <table width="606" border="2" align="center" bordercolor="#9966FF" bgcolor="#C7B6B1">
          	<tr><td colspan="3" align="center"><h3>Search Enrolment No Wise Records Here</h3></td></tr>
            <tr>
              <td width="308" bgcolor="#9999CC"><div align="center"><strong><span class="style2">Enter the enrolment no</span></strong></div></td>
              <td width="144" bgcolor="#9999CC"><span class="style6">
                <input type="text" name="eno" />
              </span></td>
              <td width="130" bgcolor="#9999CC"><input type="submit" value="View Information" name="btnsubmit"/></td>
            </tr>
          </table>
          </form>
        </div></td>
      </tr>
		<?php
		if(isset($_POST["btnsubmit"]))
		{
			include "db.php";
			extract($_POST);
			$query = "select * from `students` where student_id = ".$eno." limit 1";

			$result = mysqli_query($con,$query)or die("select error error");
			while($rec = mysqli_fetch_array($result))
			{
				echo '<tr><td colspan="2"><table width="400" border="2" align="center" bordercolor="#9966FF" bgcolor="#C7B6B1">
				<tr>
				  <td width="160" bgcolor="#9999CC"><span class="style2">Student Id</span></td>
				  <td width="160" bgcolor="#9999CC"><span class="style2">Name</span></td>';
				  $query1 = "select * from `tbl_attendance` where `student_id` = ".$rec["student_id"]." order by attendance_date";
					$result1 = mysqli_query($con,$query1)or die("select error error");
					while($rec1 = mysqli_fetch_array($result1))
					{
				  		echo '<td bgcolor="#9999CC" class=style2>'.$rec1["attendance_date"].'</td>';
					}
				echo '</tr>
				<tr>
				  <td width="222"><span class="style6">'.$rec["student_id"].'</span></td>
				  <td width="222"><span class="style6">'.$rec["fname"].'</span></td>';
				  $query1 = "select *from `tbl_attendance` where `student_id` = ".$rec["student_id"]." order by attendance_date";
					$result1 = mysqli_query($con,$query1)or die("select error error");
					while($rec1 = mysqli_fetch_array($result1))
					{
				  		echo '<td>';
						if($rec1["attendance_status"]==0)
							echo "Absent";
						else
							echo "Present";
						echo '</td>';
					}
				
				echo '
				</tr>
								
			  </table></td></tr>';
			}
		}
		else
		{
			include "db.php";
			extract($_POST);
			$query = "select * from `students` ";

			$result = mysqli_query($con,$query)or die("select error error");
			while($rec = mysqli_fetch_array($result))
			{
				echo '<tr><td colspan="2"><table width="90%" border="2" align="center" bordercolor="#9966FF" bgcolor="#C7B6B1">
				<tr>
				  <td width="160" bgcolor="#9999CC"><span class="style2">student ID</span></td>
				  <td width="160" bgcolor="#9999CC"><span class="style2">Name</span></td>';
				  $query1 = "select * from `tbl_attendance` where `student_id` = ".$rec["student_id"]." order by attendance_date";
					$result1 = mysqli_query($con,$query1)or die("select error error");
					while($rec1 = mysqli_fetch_array($result1))
					{
				  		echo '<td bgcolor="#9999CC" class=style2>'.$rec1["attendance_date"].'</td>';
					}
				echo '</tr>
				<tr>
				  <td width="222"><span class="style6">'.$rec["student_id"].'</span></td>
				  <td width="222"><span class="style6">'.$rec["fname"].'</span></td>';
				  $query1 = "select *from `tbl_attendance` where `student_id` = ".$rec["student_id"]." order by attendance_date";
					$result1 = mysqli_query($con,$query1)or die("select error error");
					while($rec1 = mysqli_fetch_array($result1))
					{
				  		echo '<td>';
						if($rec1["attendance_status"]==0)
							echo "Absent";
						else
							echo "Present";
						echo '</td>';
					}
				
				echo  '
				</tr>
								
			  </table></td></tr>';
			}
		}
		?>    
	</table>