<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");

if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
     $term=$_POST['term'];
        $sub=$_POST['sub'];
          $mark=$_POST['mark'];
     $grade=$_POST['grade'];
         $data_query="select * from mark where mid='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
      
         
         $query="update mark set term= '$term',subject= '$sub',mark= '$mark',grade= '$grade' where mid='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
            
                   $_SESSION['success'] = "Data Updated";
                   header("Location: viewmark.php");
              }
         }else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: viewmark.php");
              }
         

   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $query="delete from mark where mid='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           $_SESSION['success']="Data Deleted";
           header("Location: viewmark.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: viewmark.php");
       }
   }    
         
         