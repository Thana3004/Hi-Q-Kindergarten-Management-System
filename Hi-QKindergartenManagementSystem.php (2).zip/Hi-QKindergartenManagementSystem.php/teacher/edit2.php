<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Teacher - Edit Exam Result</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       
	<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
    session_start();
    include ('db.php');
    include ('../function.php');
    ?>
    
    <?php 
        include "navbar.php";
     ?>
    
    
    
    <div class="container-fluid">
        <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> Edit Data</h6>
        </div>
            <div class="card-body">
                <?php 
                 $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
                if (isset($_POST['data_edit'])){
                    $id=$_POST['edit_id'];
                    $query= "select * from mark where mid='$id'";
                    $query_run= mysqli_query($conn, $query);
                    foreach ($query_run as $row){
                        ?>
                <form action="code2.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="edited_id" value="<?php echo $row['mid']?>">
                   
         <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Edit Exam Mark</legend> 
          
            
             <label> Exam Term </label>
        <select name="term" required="" class="input3">
            <option value="">Select</option>
            <option value="Mid-Year Examination">Mid-Year Examination</option>
      
            <option value="Final Exam">Final Exam</option>
        </select>
             <br>
                <label> Subject </label>
        <select name="sub" required="" class="input3">
            <?php 
            $s="select * from tbl_subject";
            $re=$con->query($s);
            if ($re->num_rows>0)
            {
                echo"<option value=''>Select</option>";
                while ($r=$re->fetch_assoc())
                {
                    echo"<option value='{$r["subject_name"]}'>{$r["subject_name"]}</option>";
                }
            }
            
            ?>
        </select>
                <br>
                 <label> Mark </label>
                <input type="text" class="form-control" name="mark" maxlength="3" onkeypress="isInputNumber(event)" value="<?php echo $row['mark']?>">
                <br><!-- comment -->
                <label> Grade </label>
        <select name="grade" required class="input3">
            <option value="">Select</option>
            <option value="Pass">Pass</option>
      
            <option value="Failed">Failed</option>
        </select>
         </fieldset>
              </div>
          
        
          
         

             </div>
                    
                    <div class="modal-footer">
                        <a href ="viewmark.php"><button type="button" class="btn btn-secondary">CLOSE</button></a>
                        <button type="submit" name="update" class="btn btn-primary">UPDATE</button>
                    </div>
                    
          
                   
      </form>
                 <?php
                    }
                }
                ?>
                </div>
    </div>
    
</body>
</html>

