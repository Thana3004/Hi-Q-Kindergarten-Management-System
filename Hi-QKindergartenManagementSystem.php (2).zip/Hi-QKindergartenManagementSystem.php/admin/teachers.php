<?php 

session_start();

if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
 ?>



<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin-Teachers</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
   
    include ('../db.php/db.php');
     include ('db.php');
     include ('../function.php');
     
    ?>
    
    <?php 
        include "inc/navbar.php";
     ?>

    
    
    
    
    
    <br>
<div class="modal fade" id="demo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add Teachers Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code2.php" method="post" enctype="multipart/form-data">
      <div class="modal-body">
         
         
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Staff Details</legend> 
          <label> Name</label>
              <input type="text" name="name" class="form-control" placeholder=" Staff name "  onkeypress="return letterOnly(event)" autocomplete="off" required>
              <br>
              <label> NRIC</label>
             <input type="text" name="ic" class="form-control"  maxlength="12"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" required> 
               <br>
              <label> Gender</label>
             <input type="text" name="gender" class="form-control" placeholder="Female or Male" onkeypress="return lettersOnly(event)" autocomplete="off" required> 
               <br>
             <label> Date of birth </label>
             <input type="date" name="dob" class="form-control"  required> 
              <br>
             <label> Age </label>
             <input type="text" name="age" class="form-control" maxlength="2"  autocomplete="off"  placeholder=" Enter only numbers ! Symbol&Characters not allowed " onkeypress="isInputNumber(event)" required> 
             <br>
             <label> Home Address  </label>
             <input type="text" name="home" class="form-control"  autocomplete="off"  placeholder=" No, 5 Jalan....." required> 
             <br>
          
             <label> Class Teacher </label>
             <select  name="classteach" class="form-control"  required> 
            
                    <?php 
            $s="select * from tbl_grade";
            $re=$con->query($s);
            if ($re->num_rows>0)
            {
                echo"<option value=''>Select</option>";
                while ($r=$re->fetch_assoc())
                {
                    echo"<option value='{$r["grade_name"]}'>{$r["grade_name"]}</option>";
                }
            }
            
            ?>
             </select>
             <br>
             <label> Qualification  </label>
             <input type="text" name="qua" class="form-control"  autocomplete="off" onkeypress="return lettersOnly(event)" placeholder="Degree, SPM..." required>
              <br>
             <label> Email </label>
             <input type="text" name="mail" class="form-control"  autocomplete="off"  placeholder=" @gmail.com" required>
             <br>
             <label> Photo  </label>
             <input type="file" name="photo" class="form-control"  id="photo"   required>
            
         </fieldset>
              </div>
          
        
          
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Contact Details</legend> 
            <label> Contact Number </label>
             <input type="text" name="tel" class="form-control" maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" required> 
             </fieldset>
             </div>

           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Registration Details</legend> 
           
              <label> Joining Date </label>
             <input type="date" name="admissiondate" class="form-control"  required> 
             </fieldset>
             </div>
          
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Create User Account</legend> 
            <label> Username </label>
             <input type="text" name="uname" class="form-control"  autocomplete="off"  required> 
            
             <br>
              <label> Password</label>
             <input type="text" name="pass" class="form-control"  autocomplete="off"  required> 
             
             </fieldset>
             </div>
      
      </div>
        
      <div class="modal-footer">
           <button type="reset" class="btn btn-secondary"  name="reset">Reset</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
           <button type="submit" class="btn btn-primary"  name="save">Save</button>
      
      </div>
         </form>
    </div>
  </div>
</div>
    
     
          
    <div class="container-fluid">
        <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demo">Add Teachers</button>
        <br>
        <br>
    </div>
  
    <div class="card-body" >
        
        <div class="col-md-7">
            <form action="" method="GET">
        <div class="input-group mb-3">
            <input type="text" name="search" value="<?php if(isset($_GET['search'])){echo $_GET['search'];} ?>" class="form-control" placeholder="search data" >
            <button type="submit" class="btn btn-primary">Search</button>
</div>
            </form>  
        </div>
        
    </div>
    
    
    
    
    
    
    
    <div class="table-responsive">
        <?php
       $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
        $query ="select * from teachers";
        $query_run= mysqli_query($conn, $query);
       
        ?>
        <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0%" >
            <thead>
            <tr class="bg-dark text-light">
                <th>Teacher ID</th>
                <th> Photo</th>
                <th>Teacher Name</th>
                <th> Gender</th>
                <th> Date Of Birth</th>
                <th>Age</th>
                <th>Home Address</th>
               <th>Contact Number</th>
                <th>Qualification</th>
                <th>Email </th>
                <th>class Teacher</th>
               
                <th> Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
               
                <?php
                if (isset($_GET['search'])){
                    $filtervalues=$_GET['search'];
                    $query="select * from teachers where CONCAT(fname,phone_number,gender,address)LIKE '%$filtervalues%' ";
                    $query_run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                    if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['teacher_id']; ?></td>
                                                    <td><img src="../admin/imgteacher/<?php echo $items['photo']; ?>" width="100px" height="100px" /></td>
                                                    <td><?= $items['fname']; ?></td>                         
                                                    <td><?= $items['gender']; ?></td>
                                                       <td><?= $items['date_of_birth']; ?></td>
                                                    <td><?= $items['age']; ?></td>
                                                    <td><?= $items['address']; ?></td>
                                                    <td><?= $items['phone_number']; ?></td>
                                                    <td><?= $items['qualification']; ?></td>
                                                       <td><?= $items['email_address']; ?></td>
                                                         <td><?= $items['teacher_grade_id']; ?></td>
                                                    
                                                      
                                                    <td>
                                                         <form action="edit2.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['teacher_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                               </td>
                                     <td>
                    <form action="code2.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['teacher_id']?>" > 
                             <input type="hidden"   name="delete_img" value="<?php echo $row['photo']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</butto>
                        </form>
                   
                  
                        
                        
                    </td>                    
                                                       
                                                       
                                                       
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                    
                    }
                }
                
                ?>




                <?php
                if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                ?>
                
                <tr>
                    <td><?php echo $row['teacher_id']?></td>
                   <td><img src="../admin/imgteacher/<?php echo $row['photo']; ?>" width="100px" height="100px" /></td>
                     <td><?php echo $row['fname']?></td>
                   
                     <td><?php echo $row['gender']?></td>
                   <td><?php echo $row['date_of_birth']?></td>
                    <td><?php echo $row['age']?></td>
                   <td><?php echo $row['address']?></td>
                   <td><?php echo $row['phone_number']?></td>
                   <td><?php echo $row['qualification']?></td>
                   <td><?php echo $row['email_address']?></td>
                    <td><?php echo $row['teacher_grade_id']?></td>
                    
                    <td>
                        <form action="edit2.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['teacher_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                        
                        
                    </td>
                    <td>
                    <form action="code2.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['teacher_id']?>" > 
                             <input type="hidden"   name="delete_img" value="<?php echo $row['photo']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</butto>
                        </form>
                   
                  
                        
                        
                    </td>
                
                </tr>
                <?php
                }
                }else{
                    echo "No record Found";
                }
                    
                ?>
            </tbody>
        </table>
        
    </div>
  
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(2) a").addClass('active');
        });
    </script>


</body>

</html>
<?php 

  }else {
    header("Location: ../login1.php");
    exit;
  } 
}else {
	header("Location: ../login1.php");
	exit;
} 

?>



<!-- comment -->
