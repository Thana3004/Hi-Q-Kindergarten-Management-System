<?php 

session_start();

if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
 ?>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin-Students</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
   
    include ('../db.php/db.php');
     include ('db.php');
     include ('../function.php');
    ?>
    
    <?php 
        include "inc/navbar.php";
     ?>

    
    
    
    
    
    <br>
<div class="modal fade" id="demo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add The Student Details</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code.php" method="post" enctype="multipart/form-data">
      <div class="modal-body">
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Has student ever attend kindergarten?</legend> 
          <label> Year</label>
              <input type="text"  maxlength="4"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" name="year" class="form-control"  >
              <br>
             <label> Yes OR No</label>
             <input type="text" name="yesno" class="form-control" onkeypress="return lettersOnly(event)" autocomplete="off"  placeholder="Yes Or NO" required=""> 
         </fieldset>
              </div>
         
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Child Particular</legend> 
          <label> Name</label>
              <input type="text" name="name" class="form-control" placeholder=" Student name " onkeypress="return letterOnly(event)" autocomplete="off" required>
              <br>
             <label> Gender</label>
             <input type="text" name="gender" class="form-control" onkeypress="return lettersOnly(event)" autocomplete="off" placeholder="Female or Male" required> 
               <br>
             <label> Date of birth </label>
             <input type="date" name="dob" class="form-control"  required> 
              <br>
             <label> Age </label>
             <input type="text" name="age" class="form-control"  maxlength="2"  autocomplete="off"  placeholder=" Enter only numbers ! Symbol&Characters not allowed " onkeypress="isInputNumber(event)" required> 
             <br>
             <label> Tel </label>
             <input type="text" name="tel" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" required> 
             <br>
             <label> Home Address  </label>
             <input type="text" name="home" class="form-control"  autocomplete="off"  placeholder=" No, 5 Jalan....." required> 
             <br>
             <label> Home Language  </label>
             <input type="text" name="homelang" class="form-control" autocomplete="off" onkeypress="return letterOnly(event)" placeholder=" english/malay/mandrin..." required> 
              <br>
             <label> Student Language  </label>
             <input type="text" name="stdlang" class="form-control" autocomplete="off" onkeypress="return letterOnly(event)" placeholder=" english/malay/mandrin..." required>
              <br>
             <label> Allergies  </label>
             <input type="text" name="all" class="form-control" autocomplete="off" onkeypress="return letterOnly(event)" placeholder=" Example: seafood/dust... OR None" required>
             <br>
             <label> Photo  </label>
             <input type="file" name="photo" class="form-control"  id="photo" required>
             <br>
               <label> Class   </label>
             <select  name="class" class="form-control"  required> 
              
                    <?php 
            $s="select * from tbl_grade";
            $re=$con->query($s);
            if ($re->num_rows>0)
            {
                echo"<option value=''>Select</option>";
                while ($r=$re->fetch_assoc())
                {
                    echo"<option value='{$r["grade_name"]}'>{$r["grade_name"]}</option>";
                }
            }
            
            ?>
             </select>
         </fieldset>
              </div>
          
         <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Parents Details</legend> 
          <label> Father Name</label>
              <input type="text" name="fname" onkeypress="return letterOnly(event)" autocomplete="off" class="form-control" placeholder=" father name ">
              <br>
             <label> Father IC Number</label>
             <input type="text" name="fic" class="form-control" maxlength="12"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" > 
               <br>
             <label> Father Occupation </label>
             <input type="text" name="focc" autocomplete="off" onkeypress="return lettersOnly(event)" class="form-control" placeholder="Example: Business man, Teacher...." > 
              <br>
             <label> Father Contact Number </label>
             <input type="text" name="fcontact" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" > 
             <br>
              <label> Mother Name</label>
              <input type="text" name="mname" onkeypress="return letterOnly(event)" autocomplete="off" class="form-control" placeholder=" mother name ">
              <br>
             <label> Mother IC Number</label>
             <input type="text" name="mic" class="form-control" maxlength="12"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" > 
               <br>
             <label> Mother Occupation </label>
             <input type="text" name="mocc" autocomplete="off" onkeypress="return lettersOnly(event)" class="form-control" placeholder="Example: Business man, Teacher...." > 
              <br>
             <label> Mother Contact Number </label>
             <input type="text" name="mcontact" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" > 
             <br>
         </fieldset>
              </div>
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Guardian Details</legend> 
           <label> Guardian Name</label>
              <input type="text" name="gname" class="form-control"  onkeypress="return letterOnly(event)" autocomplete="off" placeholder=" name">
              <br>
             <label> Guardian IC Number</label>
             <input type="text" name="gic" class="form-control" maxlength="12"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" > 
               <br>
             <label> Relationship to this student </label>
             <input type="text" name="grelation" class="form-control" onkeypress="return lettersOnly(event)" autocomplete="off" placeholder="Example: grandfather, aunty" > 
              <br>
             <label> Guardian Contact Number </label>
             <input type="text" name="gcontact" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" > 
            </fieldset>
             </div>
          
          
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Emergency Details</legend> 
            <label> Contact Number </label>
             <input type="text" name="contactnum" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" required> 
             </fieldset>
             </div>

           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Registration Details</legend> 
            <label> Academic of Year </label>
             <input type="text" name="academicyear" class="form-control"  maxlength="4"  autocomplete="off" placeholder="Enter only numbers ! Symbol&Characters not allowed" onkeypress="isInputNumber(event)" required> 
             <br>
              <label> Admission Date </label>
             <input type="date" name="admissiondate" class="form-control"  required> 
             </fieldset>
             </div>
          
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Create User Account</legend> 
            <label> Username </label>
             <input type="text" name="uname" class="form-control" autocomplete="off" required> 
             <br>
              <label> Password</label>
             <input type="text" name="pass" class="form-control" autocomplete="off"  required> 
             
             </fieldset>
             </div>
      </div>
        
      <div class="modal-footer">
          <button type="reset" class="btn btn-secondary"  name="reset">Reset</button>
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="save">Save</button>
      </div>
         </form>
    </div>
  </div>
</div>
    <div class="container-fluid">
       <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demo">Add Student</button>
        <br>
        <br>
    </div>
    <div class="card-body" >
        <div class="col-md-7">
            <form action="" method="GET">
        <div class="input-group mb-3">
            <input type="text" name="search" value="<?php if(isset($_GET['search'])){echo $_GET['search'];} ?>" class="form-control" placeholder="search data" >
            <button type="submit" class="btn btn-primary">Search</button>
</div>
            </form>  
        </div>
        
    </div>
    
    
    
    
    
    
    
    <div class="table-responsive">
        <?php
       $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
        $query ="select * from students";
        $query_run= mysqli_query($conn, $query);
       
        ?>
        <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0%" >
            <thead>
            <tr>
                 <tr class="bg-dark text-light">
                <th>Student ID</th>
                <th> Photo</th>
                <th>Student Name</th>
                <th> Class</th>
                <th> Gender</th>
                <th> Date Of Birth</th>
                <th>Age</th>
                <th>Home Address</th>
                <th>Student Language</th>
                <th>Home Language</th>
                <th>Allergies</th>
                <th>Father name</th>
                 <th>Father NRIC</th>
                <th>Father Occupation</th>
                 <th>Father Contact Number</th>
                 <th>Mother name</th>
                 <th>Mother NRIC</th>
                <th>Mother Occupation</th>
                 <th>Mother Contact Number</th>
                 <th>Guardian name</th>
                 <th>Guardian NRIC</th>
                <th>Guardian Relationship With Student</th>
                <th>Guardian Contact Number</th>
                 <th>Emergency Contact Number</th>
                <th> Academic Year</th>
                <th>Admission Date</th>
                <th>Student ever attended kindergarten</th>
                 <th>Joining year of previous kindergarten</th>
                <th> Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
                <?php
                if (isset($_GET['search'])){
                    $filtervalues=$_GET['search'];
                    $query="select * from students where CONCAT(fname,student_grade_id,mobile,age)LIKE '%$filtervalues%' ";
                    $query_run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                    if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['student_id']; ?></td>
                                                    <td><img src="../admin/upload/<?php echo $items['photo']; ?>" width="100px" height="100px" /></td>
                                                    <td><?= $items['fname']; ?></td>
                                                    
                                                    <td><?= $items['student_grade_id']; ?></td>
                                                    <td><?= $items['gender']; ?></td>
                                                       <td><?= $items['dob']; ?></td>
                                                    <td><?= $items['age']; ?></td>
                                                    <td><?= $items['current_address']; ?></td>
                                                    <td><?= $items['student_language']; ?></td>
                                                       <td><?= $items['Home_language']; ?></td>
                                                         <td><?= $items['allergies']; ?></td>
                                                    <td><?= $items['father_name']; ?></td>
                                                    <td><?= $items['father_ic']; ?></td>
                                                    <td><?= $items['father_occupation']; ?></td>
                                                       <td><?= $items['father_mobile']; ?></td>
                                                           
                                                       <td><?= $items['mother_name']; ?></td>
                                                    <td><?= $items['mother_ic']; ?></td>
                                                    <td><?= $items['mother_occupation']; ?></td>
                                                    <td><?= $items['mother_mobile']; ?></td>
                                                    <td><?= $items['Guardian_name']; ?></td>
                                                       <td><?= $items['Guardian_ic']; ?></td>
                                                    <td><?= $items['Guardian_Relationship']; ?></td>
                                                    <td><?= $items['guardian_contactnum']; ?></td>
                                                    <td><?= $items['Emergency_Contactnum']; ?></td>
                                                       <td><?= $items['academic_year']; ?></td>
                                                         <td><?= $items['admission_date']; ?></td>
                                                    <td><?= $items['previouse_kindergaten']; ?></td>
                                                    <td><?= $items['year_of_previouse_kindergarten']; ?></td>
                                                    <td>
                                                         <form action="edit.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['student_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                               </td>
                                     <td>
                    <form action="code.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['student_id']?>" > 
                              <input type="hidden"   name="delete_img" value="<?php echo $row['photo']?>" > 

                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</butto>
                        </form>
                   
                  
                        
                        
                    </td>                    
                                                       
                                                       
                                                       
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                    
                    }
                }
                
                ?>
                
                <?php
                if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                ?>
                
                <tr>
                    <td><?php echo $row['student_id']?></td>
                  <td><img src="../admin/upload/<?php echo $row['photo']; ?>" width="100px" height="100px" /></td>
                     <td><?php echo $row['fname']?></td>
                   <td><?php echo $row['student_grade_id']?></td>
                     <td><?php echo $row['gender']?></td>
                   <td><?php echo $row['dob']?></td>
                    <td><?php echo $row['age']?></td>
                   <td><?php echo $row['current_address']?></td>
                    <td><?php echo $row['student_language']?></td>
                   <td><?php echo $row['Home_language']?></td>
                    <td><?php echo $row['allergies']?></td>
                    <td><?php echo $row['father_name']?></td>
                    <td><?php echo $row['father_ic']?></td>
                     <td><?php echo $row['father_occupation']?></td>
                    <td><?php echo $row['father_mobile']?></td>
                   <td><?php echo $row['mother_name']?></td>
                    <td><?php echo $row['mother_ic']?></td>
                   <td><?php echo $row['mother_occupation']?></td>
                    <td><?php echo $row['mother_mobile']?></td>
                   <td><?php echo $row['Guardian_name']?></td>
                    <td><?php echo $row['Guardian_ic']?></td>                       
                    <td><?php echo $row['Guardian_Relationship']?></td>
                    <td><?php echo $row['guardian_contactnum']?></td>
                     <td><?php echo $row['Emergency_Contactnum']?></td>
                    <td><?php echo $row['academic_year']?></td>
                     <td><?php echo $row['admission_date']?></td>
                   <td><?php echo $row['previouse_kindergaten']?></td>  
                    <td><?php echo $row['year_of_previouse_kindergarten']?></td>
                    <td>
                        <form action="edit.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['student_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                        
                        
                    </td>
                    <td>
                    <form action="code.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['student_id']?>" > 
                            <input type="hidden"   name="delete_img" value="<?php echo $row['photo']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</butto>
                        </form>
                   
                  
                        
                        
                    </td>
                
                </tr>
                <?php
                }
                }else{
                    echo "No record Found";
                }
                    
                ?>
            </tbody>
        </table>
        
    </div>
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>

</body>

</html>
<?php 

  }else {
    header("Location: ../login1.php");
    exit;
  } 
}else {
	header("Location: ../login1.php");
	exit;
} 

?>

