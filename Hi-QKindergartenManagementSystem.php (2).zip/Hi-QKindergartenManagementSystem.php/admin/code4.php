<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");


if(isset($_POST['save']))
{
    $name=$_POST['name'];
   
      
       
                $query="insert into tbl_subject(subject_name)
                                    values (' $name' )";
              
                
                $query_run= mysqli_query($conn, $query);
               
               if ($query_run){
                  
                   $_SESSION['success'] = "Class Add Successfully";
                   header("Location: subject.php");
                   
               } 
               else {
                  $_SESSION['success'] ="data not inserted";
                   header("Location: subject.php");
               }
               
            }
      
            
            
            

  if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
     $name=$_POST['name'];
       
     
         $data_query="select * from tbl_subject where subject_id='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
      
         
         $query="update tbl_subject set subject_name= '$name' where subject_id='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
            
                   $_SESSION['success'] = "Data Updated";
                   header("Location: subject.php");
              }
         else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: subject.php");
              }
  }      

   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $query="delete from tbl_subject where subject_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           $_SESSION['success']="Data Deleted";
           header("Location: subject.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: subject.php");
       }
   }    
         
         
 
      
    


?>   
