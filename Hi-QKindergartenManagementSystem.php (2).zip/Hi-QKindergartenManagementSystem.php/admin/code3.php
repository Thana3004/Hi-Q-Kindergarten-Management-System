<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");



            
            

  if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
     $name=$_POST['name'];
       $gender=$_POST['gender'];
       
           $tel=$_POST['tel'];
          $home=$_POST['home'];
    
       $email=$_POST['mail'];
        
         $uname=$_POST['uname'];
        $pass=$_POST['pass']; 
     
     
         $data_query="select * from admin where admin_id='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
      
         
         $query="update admin set fname= '$name',gender='$gender',contact='$tel',address='$home', email='$email' where admin_id='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
            
                   $_SESSION['success'] = "Data Updated";
                   header("Location: admin.php");
              }
         
              else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: admin.php");
              }
  }   
  
   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $query="delete from admin where admin_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           $_SESSION['success']="Data Deleted";
           header("Location: admin.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: admin.php");
       }
   }    
         
         
 
      
    


?>   
<?php
include ('../db.php/dbb.php');
if(isset($_POST['save']))
{
      
     $uname=$_POST['uname'];
    $query=$conn->prepare("select * from admin where username =?");
     $query->execute([$uname]);
     $result=$query->rowCount();
     if($result > 0){
         $error=  
         $_SESSION['success'] = "Email Already Taken! Pls try Another One";
        header('Location: admin.php');
     }

    
    
   
        
         $pass=$_POST['pass'];

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $name=$_POST['name'];
   
       $gender=$_POST['gender'];
       
       
           $tel=$_POST['tel'];
          $home=$_POST['home'];
  
      
       $email=$_POST['mail'];
        
        
             
            
     if (empty($error)){   
        
    $query = $conn->prepare("INSERT INTO admin(username, password,fname,gender,contact,address,email) VALUES (:uname, :pass,:name,:gender,:tel,:home,:mail)");
    $query->execute([
    
        ':uname' => $uname,
        ':pass' => $hash,
         ':name' => $name,
        
        ':gender' => $gender,
      
         ':tel' => $tel,
           ':home' => $home,
        
         ':mail' => $email,
        
        ]);
    

    if($query)
    { 
        $_SESSION['success'] = "Add Admin Successfully";
        header('Location: admin.php');
       
    }
    else
    {
        $_SESSION['success'] = "Data Not Inserted";
        header('Location: admin.php');
       
    }
}

}

?>