<html>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin- Edit Student data</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       
	<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
    session_start();
    include ('../db.php/db.php');
    include ('../function.php');
    ?>
    
    <?php 
    
        include "inc/navbar.php";
     ?>
    <div class="container-fluid">
        <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary"> Edit Data</h6>
        </div>
            <div class="card-body">
                <?php 
                 $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
                if (isset($_POST['data_edit'])){
                    $id=$_POST['edit_id'];
                    $query= "select * from admin where admin_id='$id'";
                    $query_run= mysqli_query($conn, $query);
                    foreach ($query_run as $row){
                        ?>
                <form action="code3.php" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="edited_id" value="<?php echo $row['admin_id']?>">
                   
         <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Admin Details</legend> 
          <label> Name</label>
              <input type="text" name="name" onkeypress="return letterOnly(event)" autocomplete="off" class="form-control" placeholder="  name "  value="<?php echo $row['fname']?>">
              <br>
             
              <label> Gender</label>
             <input type="text" name="gender" onkeypress="return lettersOnly(event)" autocomplete="off"  class="form-control" placeholder="Female or Male" value="<?php echo $row['gender']?>"> 
               <br>
             
            
             <label> Home Address  </label>
             <input type="text" name="home" autocomplete="off" class="form-control"  placeholder=" No, 5 Jalan....." value="<?php echo $row['address']?>"> 
            
              <br>
             <label> Email </label>
             <input type="text" name="mail" autocomplete="off" class="form-control"  placeholder=" @gmail.com" value="<?php echo $row['email']?>">
            
            
         </fieldset>
              </div>
          
        
          
           <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto"> Contact Details</legend> 
            <label> Contact Number </label>
             <input type="text" name="tel" class="form-control"  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" value="<?php echo $row['contact']?>"> 
             </fieldset>
             </div>

             </div>
                    
                    <div class="modal-footer">
                        <a href ="admin.php"><button type="button" class="btn btn-secondary">CLOSE</button></a>
                        <button type="submit" name="update" class="btn btn-primary">UPDATE</button>
                    </div>
                    
          
                   
      </form>
                 <?php
                    }
                }
                ?>
                </div>
    </div>
    
</body>
</html>

