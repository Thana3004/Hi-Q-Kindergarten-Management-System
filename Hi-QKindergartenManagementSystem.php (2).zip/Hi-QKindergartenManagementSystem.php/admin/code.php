<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");



  if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
        $name=$_POST['name'];
     $year=$_POST['year'];
       $yesno=$_POST['yesno'];
       $gender=$_POST['gender'];
       $dob=$_POST['dob'];
         $age=$_POST['age'];
           $tel=$_POST['tel'];
          $home=$_POST['home'];
     $homelang=$_POST['homelang'];
       $stdlang=$_POST['stdlang'];
       $all=$_POST['all'];
        $fname=$_POST['fname'];
        $fic=$_POST['fic']; 
         $focc=$_POST['focc'];
        $fcontact=$_POST['fcontact']; 
         
        $mname=$_POST['mname'];
        $mic=$_POST['mic']; 
         $mocc=$_POST['mocc'];
        $mcontact=$_POST['mcontact'];   
        
        $gname=$_POST['gname'];
        $gic=$_POST['gic']; 
         $grelation=$_POST['grelation'];
        $gcontact=$_POST['gcontact']; 
        
        $contactnum=$_POST['contactnum']; 
        
        $academicyear=$_POST['academicyear'];
        $admissiondate=$_POST['admissiondate']; 
         $photo=$_FILES['photo']['name'];
         
         $data_query="select * from students where student_id='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
         foreach ($data_query_run as $fa_row) {
             if ($photo==NULL)
             {
                 $image_data=$fa_row['photo'];
              
             }
             else {
                 if ($img_path="upload/" .$fa_row['photo']){
                     unlink($img_path);
                     $image_data=$photo;
                 }
             }
             
         }
         
         $query="update students set fname= '$name',year_of_previouse_kindergarten='$year',previouse_kindergaten='$yesno',gender='$gender',dob='$dob',age='$age',mobile='$tel',current_address='$home',Home_language='$homelang',student_language='$stdlang',allergies='$all',photo='$photo',father_name='$fname',father_ic='$fic',father_occupation='$focc',father_mobile='$fcontact',mother_name='$mname',mother_ic='$mic',mother_occupation='$mocc',mother_mobile='$mocc',Guardian_name='$gname',Guardian_ic='$gic',Guardian_Relationship='$grelation',guardian_contactnum='$gcontact',Emergency_Contactnum='$contactnum', academic_year='$academicyear',admission_date='$admissiondate' where student_id='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
              if ($photo == NULL){
                  $_SESSION['success']= "Data Updated";
                  header('location: students.php');
              }else{
                  move_uploaded_file($_FILES["photo"]["tmp_name"],"upload/" .$_FILES["photo"]["name"]);
                   $_SESSION['success'] = "Data Updated";
                   header("Location: students.php");
              }
         }
              else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: students.php");
              }
         }
  
   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $img=$_POST['delete_img'];
       
       $query="delete from students where student_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           unlink("upload/".$img);
           $_SESSION['success']="Data Deleted";
           header("Location: students.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: students.php");
       }
   }    
         
         
 

?>  
<?php
include ('../db.php/dbb.php');
if(isset($_POST['save']))
{
      
     $uname=$_POST['uname'];
    $query=$conn->prepare("select * from students where username =?");
     $query->execute([$uname]);
     $result=$query->rowCount();
     if($result > 0){
         $error=  
         $_SESSION['success'] = "Email Already Taken! Pls try Another One";
        header('Location: students.php');
     }

    
    
   
        
         $pass=$_POST['pass'];

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        
        $name=$_POST['name'];
      $year=$_POST['year'];
       $yesno=$_POST['yesno'];
       $gender=$_POST['gender'];
       $dob=$_POST['dob'];
         $age=$_POST['age'];
           $tel=$_POST['tel'];
          $home=$_POST['home'];
     $homelang=$_POST['homelang'];
       $stdlang=$_POST['stdlang'];
       $all=$_POST['all'];
        
        
        $fname=$_POST['fname'];
        $fic=$_POST['fic']; 
         $focc=$_POST['focc'];
        $fcontact=$_POST['fcontact']; 
         $class=$_POST['class'] ;
        $mname=$_POST['mname'];
        $mic=$_POST['mic']; 
         $mocc=$_POST['mocc'];
        $mcontact=$_POST['mcontact']; 
        
         $gname=$_POST['gname'];
        $gic=$_POST['gic']; 
         $grelation=$_POST['grelation'];
        $gcontact=$_POST['gcontact']; 
        
        
          $contactnum=$_POST['contactnum']; 
        
        $academicyear=$_POST['academicyear'];
        $admissiondate=$_POST['admissiondate']; 
         
        
        
       $photo=$_FILES['photo']['name'];
             
            
     if (empty($error)){   
        
    $query = $conn->prepare("INSERT INTO students (username, password,fname,year_of_previouse_kindergarten,previouse_kindergaten,gender,dob,age,mobile,current_address,Home_language,student_language,allergies,father_name,father_ic,father_occupation,father_mobile,student_grade_id,mother_name,mother_ic,mother_occupation,mother_mobile,Guardian_name,Guardian_ic,Guardian_Relationship,guardian_contactnum,Emergency_Contactnum,academic_year,admission_date,photo) VALUES (:uname, :pass,:name,:year,:yesno,:gender,:dob,:age,:tel,:home,:homelang,:stdlang,:all,:fname,:fic,:focc,:fcontact,:class,:mname,:mic,:mocc,:mcontact,:gname,:gic,:grelation,:gcontact,:contactnum,:academicyear,:admissiondate,:photo)");
    $query->execute([
    
        ':uname' => $uname,
        ':pass' => $hash,
         ':name' => $name,
         ':year' => $year,
        ':yesno' => $yesno,
        ':gender' => $gender,
        ':dob' => $dob,
         ':age' => $age,
         ':tel' => $tel,
           ':home' => $home,
        ':homelang' => $homelang,
         ':stdlang' => $stdlang,
         ':all' => $all,
         
        
        
        
        
        
         ':fname' => $fname,
         ':fic' => $fic,
         ':focc' => $focc,
          ':fcontact' => $fcontact,
         ':class' => $class,
        ':mname' => $mname,
         ':mic' => $mic,
         ':mocc' => $mocc,
          ':mcontact' => $mcontact,
        
        ':gname' => $gname,
         ':gic' => $gic,
         ':grelation' => $grelation,
          ':gcontact' => $gcontact,
        
        ':contactnum' => $contactnum,
         ':academicyear' => $academicyear,
          ':admissiondate' => $admissiondate,
         ':photo' => $photo,
        ]);
    

    if($query)
    { move_uploaded_file($_FILES["photo"]["tmp_name"],"upload/" .$_FILES["photo"]["name"]);
        $_SESSION['success'] = "Add Student Successfully";
        header('Location: students.php');
       
    }
    else
    {
        $_SESSION['success'] = " Data Not Inserted";
        header('Location: students.php');
       
    }
}

}

?>