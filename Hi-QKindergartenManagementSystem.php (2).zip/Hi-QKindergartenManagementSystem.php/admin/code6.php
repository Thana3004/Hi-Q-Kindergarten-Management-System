<?php

session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");

if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $query="delete from tbl_contact where tbl_contact_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           $_SESSION['success']="Data Deleted";
           header("Location: message.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: message.php");
       }
   }    
         
         