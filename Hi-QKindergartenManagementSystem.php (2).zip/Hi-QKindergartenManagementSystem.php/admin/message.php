<?php 

session_start();

if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
 ?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin- Subject</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
   
    include ('../db.php/db.php');
    
    ?>
    
    <?php 
        include "inc/navbar.php";
     ?>

    <div class="container-fluid">
        <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>
        
    </div>



  <div class="card-body" >
        <div class="col-md-7">
            <form action="" method="GET">
        <div class="input-group mb-3">
            <input type="text" name="search" value="<?php if(isset($_GET['search'])){echo $_GET['search'];} ?>" class="form-control" placeholder="search data" >
            <button type="submit" class="btn btn-primary">Search</button>
</div>
            </form>  
        </div>
        
    </div>
    
    
    <div class="table-responsive">
        <?php
       $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
        $query ="select * from tbl_contact";
        $query_run= mysqli_query($conn, $query);
       
        ?>
        <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0%" >
            <thead>
            <tr>
                 <tr class="bg-dark text-light">
                
                <th> Name</th>
                <th> Contact Number</th>
                <th>Message</th>
                <th>Action</th>
            </tr>
            </thead>
            <tbody>
               
                <?php
                if (isset($_GET['search'])){
                    $filtervalues=$_GET['search'];
                    $query="select * from tbl_contact where CONCAT(fullname,contact_number)LIKE '%$filtervalues%' ";
                    $query_run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                    if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['fullname']; ?></td>
                                              
                                                    <td><?= $items['contact_number']; ?></td>                         
                                                   <td><?= $items['user_message']; ?></td>    
                                                    
                         
                                     <td>
                    <form action="code6.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['tbl_contact_id']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</button>
                        </form>
                   
                  
                        
                        
                    </td>                    
                                                       
                                                       
                                                       
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                    
                    }
                }
                
                ?>




                <?php
                if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                ?>
                
                <tr>
                    <td><?php echo $row['fullname']?></td>
                       <td><?php echo $row['contact_number']?></td>
                   <td><?php echo $row['user_message']?></td>
                   
                    <td>
                    <form action="code6.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['tbl_contact_id']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</button>
                        </form>
                   
                  
                        
                        
                    </td>
                
                </tr>
                <?php
                }
                }else{
                    echo "No record Found";
                }
                    
                ?>
            </tbody>
        </table>
        
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(9) a").addClass('active');
        });
    </script>
</body>
 <?php 

  }else {
    header("Location: ../login1.php");
    exit;
  } 
}else {
	header("Location: ../login1.php");
	exit;
} 

?>