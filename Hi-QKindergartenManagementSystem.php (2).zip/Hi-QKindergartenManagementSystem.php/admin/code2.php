<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");




  if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
     $name=$_POST['name'];
     $ic=$_POST['ic'];
       $gender=$_POST['gender'];
       $dob=$_POST['dob'];
         $age=$_POST['age'];
           $tel=$_POST['tel'];
          $home=$_POST['home'];
       
       $Qualification =$_POST['qua'];
       $email=$_POST['mail'];
        
        
      
        $admissiondate=$_POST['admissiondate']; 
        
         $uname=$_POST['uname'];
        $pass=$_POST['pass']; 
      
         $photo=$_FILES['photo']['name'];
         
         $data_query="select * from teachers where teacher_id='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
         foreach ($data_query_run as $fa_row) {
             if ($photo==NULL)
             {
                 $image_data=$fa_row['photo'];
              
             }
             else {
                 if ($img_path="..admin/imgteacher/" .$fa_row['photo'])
                 {
                     unlink($img_path);
                     $image_data=$photo;
                 }
             }
             
         }
         
         $query="update teachers set fname= '$name',gender='$gender',date_of_birth='$dob',age='$age',phone_number='$tel',address='$home',photo='$photo',ic='$ic',joining_date='$admissiondate',email_address='$email',qualification='$Qualification' where teacher_id='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
              if ($photo == NULL){
                  $_SESSION['success']= "Data Updated";
                  header('location: teachers.php');
              }else{
                  move_uploaded_file($_FILES["photo"]["tmp_name"],"imgteacher/" .$_FILES["photo"]["name"]);
                   $_SESSION['success'] = "Data Updated";
                   header("Location: teachers.php");
              }
         }
              else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: teachers.php");
              }
         }
  
  
   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
        $img=$_POST['delete_img'];
       $query="delete from teachers where teacher_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           unlink("imgteacher/".$img);
           $_SESSION['success']="Data Deleted";
           header("Location: teachers.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: teachers.php");
       }
   }    
         
         
 
      
    


?>  
<?php
include ('../db.php/dbb.php');
if(isset($_POST['save']))
{
      
     $uname=$_POST['uname'];
    $query=$conn->prepare("select * from teachers where username =?");
     $query->execute([$uname]);
     $result=$query->rowCount();
     if($result > 0){
         $error=  
         $_SESSION['success'] = "Email Already Taken! Pls try Another One";
        header('Location: teachers.php');
     }

    
    
   
        
         $pass=$_POST['pass'];

        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $name=$_POST['name'];
     $ic=$_POST['ic'];
       $gender=$_POST['gender'];
       $dob=$_POST['dob'];
         $age=$_POST['age'];
           $tel=$_POST['tel'];
          $home=$_POST['home'];
  
       $Qualification =$_POST['qua'];
       $email=$_POST['mail'];
        
        $class=$_POST['classteach'];
      
        $admissiondate=$_POST['admissiondate']; 
        
        
       $photo=$_FILES['photo']['name'];
             
            
     if (empty($error)){   
        
    $query = $conn->prepare("INSERT INTO teachers (username, password,fname,ic,gender,date_of_birth,age,phone_number,address,qualification,email_address,teacher_grade_id,joining_date,photo) VALUES (:uname, :pass,:name,:ic,:gender,:dob,:age,:tel,:home,:qua,:mail,:classteach,:admissiondate,:photo)");
    $query->execute([
    
        ':uname' => $uname,
        ':pass' => $hash,
         ':name' => $name,
         ':ic' => $ic,
        ':gender' => $gender,
        ':dob' => $dob,
         ':age' => $age,
         ':tel' => $tel,
           ':home' => $home,
         ':qua' => $Qualification,
         ':mail' => $email,
         ':classteach' => $class,
          ':admissiondate' => $admissiondate,
         ':photo' => $photo,
        ]);
    

    if($query)
    { move_uploaded_file($_FILES["photo"]["tmp_name"],"imgteacher/" .$_FILES["photo"]["name"]);
        $_SESSION['success'] = "Add Teacher Successfully";
        header('Location: teachers.php');
       
    }
    else
    {
        $_SESSION['success'] = "Data Not Inserted";
        header('Location: teachers.php');
       
    }
}

}

?>