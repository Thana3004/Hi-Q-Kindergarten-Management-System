<?php
session_start();
include ('../db.php/db.php');
$conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");


if(isset($_POST['save']))
{
   
   $etype=$_POST['etype'];
     $date=$_POST['date'];    
      $class=$_POST['class'];
       $sub=$_POST['sub'];
        $time=$_POST['time'];
                $query="insert into tbl_exam(exam_type,exam_date, class, subject,duration)
                                    values ('$etype',' $date', '$class','$sub','$time' )";
              
                
                $query_run= mysqli_query($conn, $query);
               
               if ($query_run){
                  
                   $_SESSION['success'] = " Successfully Add Exam Timetable";
                   header("Location: setexam.php");
               }   
             else {
                  $_SESSION['success'] ="Data Not Inserted ";
                   header("Location: setexam.php");
               }
}   
            
          
           

  if (isset($_POST['update']))  {
      $id=$_POST['edited_id'];
  
   
     $date=$_POST['date'];    
    
      $time=$_POST['time'];   
         $data_query="select * from tbl_exam where exam_id='$id'";
         $data_query_run= mysqli_query($conn, $data_query);
      
         
         $query="update tbl_exam set exam_date='$date',duration='$time' where exam_id='$id'";
         $query_run= mysqli_query($conn, $query);
         if($query_run){
            
                   $_SESSION['success'] = "Data Updated";
                   header("Location: setexam.php");
              }
         
              else{
                   $_SESSION['success'] = "Data not Updated";
                   header("Location: setexam.php");
              }
  }    
 


   if (isset($_POST['data_delete']))  {
       $id=$_POST['delete_id'];
       $query="delete from tbl_exam where exam_id='$id'";
       $query_run= mysqli_query($conn, $query);
       if($query_run){
           $_SESSION['success']="Data Deleted";
           header("Location: setexam.php");
       }else{
            $_SESSION['success']="Data Not Deleted";
             header("Location: setexam.php");
       }
   }    
         
         
 
      
    


?>   
