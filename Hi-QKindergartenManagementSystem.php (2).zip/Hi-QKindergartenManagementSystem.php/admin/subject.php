<?php 

session_start();

if (isset($_SESSION['admin_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Admin') {
 ?>

<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin- Subject</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
       





<link rel="icon" href="../logo.php/logo.jpeg">
  
</head>

<body>
    <?php
   
    include ('../db.php/db.php');
    
    ?>
    
    <?php 
        include "inc/navbar.php";
     ?>

    
    
    
    
    
    <br>
<div class="modal fade" id="demo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add subject</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
        <form action="code4.php" method="post" enctype="multipart/form-data">
      <div class="modal-body">
         
         
          <div class="form-group">
         <fieldset class="border p-3">
          <legend  class="w-auto">Subject Details</legend> 
          <label> Subject Name</label>
              <input type="text" name="name" class="form-control" placeholder=" Subject name " autocomplete="off" required>
              <br>
         
            
         </fieldset>
              </div>
          
        
      </div>
        
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" name="save">Save</button>
      </div>
         </form>
    </div>
  </div>
</div>
    <div class="container-fluid">
        <?php
        if (isset($_SESSION['success']) && $_SESSION['success'] !='')
        {
            ?>
        <div class="alert alert-info alert-dismissible fade show" role="alert">
                <strong></strong> <?= $_SESSION['success']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        
        <?php
            unset($_SESSION['success']);   
        }
         if (isset($_SESSION['status']) && $_SESSION['status'] !='')
        {
            echo'<h2 class="bg-success text-white"> '.$_SESSION['status'].'</h2>';
            unset($_SESSION['status']);   
        }
        
        
        ?>
        <button type="button" class="btn btn-success" data-toggle="modal" data-target="#demo">Add subject</button>
        <br>
        <br>
    </div>
   
    <div class="card-body" >
        <div class="col-md-7">
            <form action="" method="GET">
        <div class="input-group mb-3">
            <input type="text" name="search" value="<?php if(isset($_GET['search'])){echo $_GET['search'];} ?>" class="form-control" placeholder="search data" >
            <button type="submit" class="btn btn-primary">Search</button>
</div>
            </form>  
        </div>
        
    </div>
    
    
    
    
    
    
    
    <div class="table-responsive">
        <?php
       $conn = mysqli_connect("localhost","root", "","kindergartenmanagementsystem");
        $query ="select * from tbl_subject";
        $query_run= mysqli_query($conn, $query);
       
        ?>
        <table class="table table-bordered text-center" id="dataTable" width="100%" cellspacing="0%" >
            <thead>
            <tr>
                 <tr class="bg-dark text-light">
                <th>Subject ID</th>
                <th> Name</th>
                <th> Edit</th>
                <th>Delete</th>
            </tr>
            </thead>
            <tbody>
               
                <?php
                if (isset($_GET['search'])){
                    $filtervalues=$_GET['search'];
                    $query="select * from tbl_subject where CONCAT(subject_name)LIKE '%$filtervalues%' ";
                    $query_run = mysqli_query($conn, $query);
                    if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                    if(mysqli_num_rows($query_run) > 0)
                                        {
                                            foreach($query_run as $items)
                                            {
                                                ?>
                                                <tr>
                                                    <td><?= $items['subject_id']; ?></td>
                                              
                                                    <td><?= $items['subject_name']; ?></td>                         
                                                 
                                                    
                                                      
                            <td>
                                                         <form action="edit4.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['subject_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                               </td>
                                     <td>
                    <form action="code4.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['subject_id']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</button>
                        </form>
                   
                  
                        
                        
                    </td>                    
                                                       
                                                       
                                                       
                                                </tr>
                                                <?php
                                            }
                                        }
                                        else
                                        {
                                            ?>
                                                <tr>
                                                    <td colspan="4">No Record Found</td>
                                                </tr>
                                            <?php
                                        }
                                    }
                    
                    }
                }
                
                ?>




                <?php
                if (mysqli_num_rows($query_run)> 0){
                    while($row= mysqli_fetch_assoc($query_run)){
                
                ?>
                
                <tr>
                    <td><?php echo $row['subject_id']?></td>
                       <td><?php echo $row['subject_name']?></td>
                  
                    
                    <td>
                        <form action="edit4.php" method="post">
                            <input type="hidden"   name="edit_id" value="<?php echo $row['subject_id']?>" > 
                            <button type="submit" name="data_edit" class="btn btn-info"> EDIT</button>
                        </form>
                        
                        
                    </td>
                    <td>
                    <form action="code4.php" method="post">
                            <input type="hidden"   name="delete_id" value="<?php echo $row['subject_id']?>" > 
                            <button type="submit" name="data_delete" class="btn btn-warning"> DELETE</button>
                        </form>
                   
                  
                        
                        
                    </td>
                
                </tr>
                <?php
                }
                }else{
                    echo "No record Found";
                }
                    
                ?>
            </tbody>
        </table>
        
    </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(6) a").addClass('active');
        });
    </script>

</body>

</html>
<?php 

  }else {
    header("Location: ../login1.php");
    exit;
  } 
}else {
	header("Location: ../login1.php");
	exit;
} 

?>