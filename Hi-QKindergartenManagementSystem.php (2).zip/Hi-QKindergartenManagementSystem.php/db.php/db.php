<?php  

$sName = "localhost";
$uName = "root";
$pass  = "";
$db_name = "kindergartenmanagementsystem";

try {
	$conn = new PDO("mysql:host=$sName;dbname=$db_name", $uName, $pass);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOExeption $e){
	echo "Connection failed: ". $e->getMessage();
	exit;
}




function load_grade_list($conn)
{
 $query = "
 SELECT * FROM tbl_grade 
 ";
 $statement = $conn->prepare($query);
 $statement->execute();
 $result = $statement->fetchAll();
 $output = '';
 foreach($result as $row)
 {
  $output .= '<option value="'.$row["grade_id"].'">'.$row["grade_name"].'</option>';
 }
 return $output;
}

function load_subject_list($conn)
{
 $query = "
 SELECT * FROM tbl_subject
 ";
 $statement = $conn->prepare($query);
 $statement->execute();
 $result = $statement->fetchAll();
 $output = '';
 foreach($result as $row)
 {
  $output .= '<option value="'.$row["subject_id"].'">'.$row["subject_name"].'</option>';
 }
 return $output;
}
