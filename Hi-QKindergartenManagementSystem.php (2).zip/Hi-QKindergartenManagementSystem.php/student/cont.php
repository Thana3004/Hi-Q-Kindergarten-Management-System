<?php
	$firstName = $_POST['firstName'];
	$email = $_POST['email'];
	
	$number = $_POST['number'];
	

	// Database connection
	$conn = new mysqli('localhost','root','','kindergartenmanagementsystem');
	if($conn->connect_error){
		echo "$conn->connect_error";
		die("Connection Failed : ". $conn->connect_error);
	} else {
		$stmt = $conn->prepare("insert into tbl_contact(fullname, contact_number,user_message) values('$firstName', '$number', '$email')");
		
		$execval = $stmt->execute();
		echo $execval;
		echo"<script>alert('Succefully send! The admin will contact you soon!')</script>";
		 echo "<script>window.open('contact.php','_self')</script>";
               
                $stmt->close();
		$conn->close();
	}
?>       