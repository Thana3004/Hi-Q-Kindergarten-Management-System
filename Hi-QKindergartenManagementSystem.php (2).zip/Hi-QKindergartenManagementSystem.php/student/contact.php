<?php 

session_start();
if (isset($_SESSION['student_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Parent') {
 
        
        
   
?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Parent- Contact</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href=" css/css.css">
   <link rel="icon" href="../logo.php/logo.jpeg"> 




  
</head>

<body>
    <?php
  include ('../function.php');
     include ('../db.php/db.php');
    
    ?>
    
    <?php 
        include "navbar.php";
     ?>

    
    


<body>
<br>
<br>
   <div class="container">
      <div class="row col-md-6 col-md-offset-3">
        <div class="panel panel-primary">
          <div class="panel-heading text-center">
            <h1  text-align="center" >Feedback/Complaint Form</h1>
          </div>
          <div class="panel-body">
            <form action="cont.php" method="post" >
              <div class="form-group">
                <label for="firstName" >Fullname</label>
                <input
                  type="text"
                  class="form-control"
                  id="firstName"
                  name="firstName"
                  onkeypress="return letterOnly(event)" autocomplete="off" required=""
                  />
              </div>
               <div class="form-group">
                <label for="number">Phone Number</label>
                <input
                  type="text"
                  class="form-control"
                  id="number"
                  name="number"
                  maxlength="11"   autocomplete="off"  onkeypress="isInputNumber(event)" placeholder=" Enter only numbers ! Symbol&Characters not allowed" required=""
                />
              </div>
              <div class="form-group">
                <label for="email">Message</label>
                 <textarea id="email" name="email" required="" placeholder="Write something.." style="height:200px"></textarea>
              </div>
                 <button type="reset" class="btn btn-secondary"  name="reset">Reset</button>
              <input type="submit" class="btn btn-primary" />
            </form>
          </div>
         
        </div>
      </div>
    </div>

  </body>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(3) a").addClass('active');
        });
    </script>

</html>
<?php 

  }else {
    header("Location: ../login3.php");
    exit;
  } 
}else {
	header("Location: ../login3.php");
	exit;
} 

?>