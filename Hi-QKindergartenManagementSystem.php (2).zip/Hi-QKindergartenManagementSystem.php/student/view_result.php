<?php 

session_start();
if (isset($_SESSION['student_id']) && 
    isset($_SESSION['role'])) {

    if ($_SESSION['role'] == 'Parent') {
 
        
        
   
?>
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Parent- View Result</title>
	
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<link rel="stylesheet" href=" css/css.css">
   <link rel="icon" href="../logo.php/logo.jpeg"> 




  
</head>

<body>
    <?php
  include ('../function.php');
     include ('db.php');
    
    ?>
    
    <?php 
        include "navbar.php";
     ?>

    
    


<body>
    
    <div class="content" align="center">
        <br>
        <form method="post"  action="<?php echo $_SERVER["PHP_SELF"];?>">
            <div class="1box" >
                <label> <h3> Enter Student Id </label></h3>
                <br>
                <input type="" autocomplete="off"  onkeypress="isInputNumber(event)" class="input3" name="rno" required="">
            </div>
            <br>
            <button type="submit" class="btn-primary" name="view"> View Exam Result</button> <br><br><a href="view_result.php" class="btn-primary">Go Back</a>
                     
        
        
        
        
        </form>
        <br><!-- comment -->
        <div class="Output">
            <?php
            if (isset($_POST["view"])){
                echo"<h3> Exam Result </h3><br>";
                $sql="select * from mark where student_id='{$_POST["rno"]}'";
                $re=$con->query($sql);
                if ($re->num_rows>0)
                {
                    echo '<table border="3px" width="80%">
                    <tr>
                    <th> S.No</th>
                    <th> Student Id</th>
                        <th> Name</th>
                    <th> Class</th>
                    <th> Term</th>
                    <th> Subject</th>
                    <th> Mark</th>
                    <th> Grade</th>
                    </tr>
                    ';
                    $i=0;
                    while($r=$re->fetch_assoc())
                    {
                        $i++;
                        echo "
                            <tr>
                            <td>{$i}</td>
                           <td>{$r["student_id"]}</td>
                               <td>{$r["name"]}</td>
                             <td>{$r["class"]}</td>
                                     <td>{$r["term"]}</td>
                                           <td>{$r["subject"]}</td>
                                               <td>{$r["mark"]}</td> 
                                                    <td>{$r["grade"]}</td>  
                                                   <tr>";
                                               
                                
                    }
                    
                }else{
                    echo"No Record Found";
                }
                echo"</table>";
                }
            
            
            ?>
        </div>
    </div>
<br>
        <div class="text-center" >
            <button onclick=" window.print()" class=" btn btn-primary">Print</button>
            
        </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js"></script>	
    <script>
        $(document).ready(function(){
             $("#navLinks li:nth-child(2) a").addClass('active');
        });
    </script>


</body>
</html>
<?php 

  }else {
    header("Location: ../login3.php");
    exit;
  } 
}else {
	header("Location: ../login3.php");
	exit;
} 

?>